/*
Copyright (c) 2013-2014, Altera Corporation.  All rights reserved.

Redistribution and use of this software, in source and binary code forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of Altera Corporation nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

4. This software may only be used to run on Altera products, or to program Altera devices.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF THE COPYRIGHT HOLDERS OR CONTRIBUTORS ARE ADVISED OF THE POSSIBILITY DAMAGE IS LIKELY TO OCCUR.
 */

/* standard includes */
#include    <stdint.h>
//#include    <stdio.h>
//#include    <string.h>
#include "core.h"
#include "mem.h"

/* SoCAL layer includes*/
#include    "socal/hps.h"
#include    "socal/socal.h"
#include    "socal/alt_rstmgr.h"
#include    "socal/alt_gpio.h"

/* Hardware Libraries includes */
#include    "alt_clock_manager.h"
#include    "alt_watchdog.h"
#include    "alt_mpu_registers.h"

/* Some useful definitions */

/* GPIO defs. */

#define     ALT_AMP_DEMO_MPU1_LED0_MSK      0x00008000
#define     ALT_AMP_DEMO_MPU1_LED1_MSK      0x00004000
#define     ALT_AMP_DEMO_MPU1_LED2_MSK      0x00002000
#define     ALT_AMP_DEMO_MPU1_LED3_MSK      0x00001000
#define     ALT_AMP_DEMO_MPU1_DIP0_MSK      0x00020000

#define     alt_toggle_LED0()               alt_xorbits_word(ALT_GPIO1_SWPORTA_DR_ADDR, ALT_AMP_DEMO_MPU1_LED0_MSK)
#define     alt_toggle_LED1()               alt_xorbits_word(ALT_GPIO1_SWPORTA_DR_ADDR, ALT_AMP_DEMO_MPU1_LED1_MSK)
#define     alt_toggle_LED2()               alt_xorbits_word(ALT_GPIO1_SWPORTA_DR_ADDR, ALT_AMP_DEMO_MPU1_LED2_MSK)
#define     alt_toggle_LED3()               alt_xorbits_word(ALT_GPIO1_SWPORTA_DR_ADDR, ALT_AMP_DEMO_MPU1_LED3_MSK)
#define     alt_toggle_all_LEDs()           alt_xorbits_word(ALT_GPIO1_SWPORTA_DR_ADDR, ALT_AMP_DEMO_MPU1_LED0_MSK \
                                            | ALT_AMP_DEMO_MPU1_LED1_MSK | ALT_AMP_DEMO_MPU1_LED2_MSK \
                                            | ALT_AMP_DEMO_MPU1_LED3_MSK)
/* Functions found in main.c */

extern void idle_cpu();
extern void wakeup_cpu();


int32_t alt_amp_baremetal_reset_mpu0(void)
{
    uint32_t tmp, i = 64;

    // put cpu0 into reset mode
    alt_setbits_word(ALT_RSTMGR_MPUMODRST_ADDR, ALT_RSTMGR_MPUMODRST_CPU0_SET_MSK);
    while (i--)
    {
        tmp = alt_read_word(ALT_RSTMGR_MPUMODRST_ADDR);
        // minimum 64 osc1_clk cycles delay is necessary between each
        // change of this field to keep the proper reset/clkoff sequence
    }

    // and release it
    alt_clrbits_word(ALT_RSTMGR_MPUMODRST_ADDR, ALT_RSTMGR_MPUMODRST_CPU0_SET_MSK);
    return 0;

}


int32_t alt_amp_gpio_setup(void)
{
    // Enable HPS LEDs (set relevant GPIO1 bits to output)
    alt_setbits_word(ALT_GPIO1_SWPORTA_DR_ADDR,
            (ALT_AMP_DEMO_MPU1_LED0_MSK | ALT_AMP_DEMO_MPU1_LED1_MSK |
            ALT_AMP_DEMO_MPU1_LED2_MSK  | ALT_AMP_DEMO_MPU1_LED3_MSK));
    // Turn off all LEDs
    alt_setbits_word(ALT_GPIO1_SWPORTA_DDR_ADDR,
            (ALT_AMP_DEMO_MPU1_LED0_MSK | ALT_AMP_DEMO_MPU1_LED1_MSK |
            ALT_AMP_DEMO_MPU1_LED2_MSK  | ALT_AMP_DEMO_MPU1_LED3_MSK));
    return 0;
}

void cpu0_heartbeat(void)
{
    alt_amp_gpio_setup();
    alt_toggle_LED3();
    uint64_t    count;

    while(1)
    {
        /* Imprecise delay between LED toggles w/ embedded "wfe" call. */
        for (count = 0; count <= 10000000; count++);
        alt_toggle_LED0();
	/* Always try to "wakeup" CPU1, even if it's not in WFE mode. */
	wakeup_cpu();	
    }
}

void cpu1_heartbeat(void)
{

    // setup gpio to toggle LED
    alt_amp_gpio_setup();
    alt_toggle_LED0();
    uint64_t count;

    while(1)
    {
        /* Imprecise (and faster) delay on than cpu0 on LED0. */
        for (count = 0; count <= 1000000; count++);
        alt_toggle_LED1();
	/* If DIPSW0 is ON then idle CPU1. This forces CPU1 to "heartbeat" at the same rate as CPU0. */
        if (alt_read_word(ALT_GPIO2_EXT_PORTA_ADDR) & ALT_AMP_DEMO_MPU1_DIP0_MSK)
	{
	    printf("CPU1: put myself to sleep...\n");
            idle_cpu();
	}
    }
  
}

