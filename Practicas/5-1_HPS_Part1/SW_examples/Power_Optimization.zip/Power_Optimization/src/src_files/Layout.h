#ifndef LAYOUT_H
#define LAYOUT_H
#define System_Peripherals_Address	0xff200000
#define System_Peripherals_Size   	0x00e00000
#define System_Peripherals_AddrEnd	0x100000000
#define System_Memory_For_Baremetal_App_Address	0x00000000
#define System_Memory_For_Baremetal_App_Size   	0x0000f000
#define System_Memory_For_Baremetal_App_AddrEnd	0x0000f000
#define System_Stack_for_cpu_1_Address	0x0000f000
#define System_Stack_for_cpu_1_Size   	0x00001000
#define System_Stack_for_cpu_1_AddrEnd	0x00010000
#define System_Memory_for_Uboot_Address	0x3ff00000
#define System_Memory_for_Uboot_Size   	0x00100000
#define System_Memory_for_Uboot_AddrEnd	0x40000000
#define System_TLB_for_app_Address	0x00010000
#define System_TLB_for_app_Size   	0x00008000
#define System_TLB_for_app_AddrEnd	0x00018000
#define uboot_Memory_for_Uboot_Address	0x3ff00000
#define uboot_Memory_for_Uboot_Size   	0x00100000
#define uboot_Memory_for_Uboot_AddrEnd	0x40000000
#define app_Peripherals_Address	0xff200000
#define app_Peripherals_Size   	0x00e00000
#define app_Peripherals_AddrEnd	0x100000000
#define app_Peripherals_MapTo  	0xff200000
#define app_Memory_For_Baremetal_App_Address	0x00000000
#define app_Memory_For_Baremetal_App_Size   	0x0000f000
#define app_Memory_For_Baremetal_App_AddrEnd	0x0000f000
#define app_Memory_For_Baremetal_App_MapTo  	0x00000000
#define app_Stack_for_cpu_1_Address	0x0000f000
#define app_Stack_for_cpu_1_Size   	0x00001000
#define app_Stack_for_cpu_1_AddrEnd	0x00010000
#define app_Stack_for_cpu_1_MapTo  	0x0000f000
#define app_TLB_for_app_Address	0x00010000
#define app_TLB_for_app_Size   	0x00008000
#define app_TLB_for_app_AddrEnd	0x00018000
#define app_TLB_for_app_MapTo  	0x00010000
#define app_Executable_Address	(0x00000040 + app_Memory_For_Baremetal_App_Address)
#define cpu0_Stack_End	0x0000f000
#define cpu1_Stack_End	0x00010000

#ifndef ASM
#include "core.h"
#include "gic.h"
#include "alt_mmu.h"
void SetupTZMemAccess();
void SetupTZInterrupts();
void SetupTZPeripherals();

uint32_t * Map_app(void);
static ALT_MMU_MEM_REGION_t app_regions[] = {
	{(void *)app_Memory_For_Baremetal_App_MapTo,   //0x00000000
	 (void *)app_Memory_For_Baremetal_App_Address, //0x00000000
	 app_Memory_For_Baremetal_App_Size,    //0x0000f000
	 ALT_MMU_AP_FULL_ACCESS,
	 ALT_MMU_ATTR_NC_NC,
	 ALT_MMU_TTB_S_NON_SHAREABLE,
	 ALT_MMU_TTB_XN_DISABLE,
	 ALT_MMU_TTB_NS_SECURE},
	{(void *)app_Stack_for_cpu_1_MapTo,   //0x0000f000
	 (void *)app_Stack_for_cpu_1_Address, //0x0000f000
	 app_Stack_for_cpu_1_Size,    //0x00001000
	 ALT_MMU_AP_FULL_ACCESS,
	 ALT_MMU_ATTR_WBA_WBA,
	 ALT_MMU_TTB_S_NON_SHAREABLE,
	 ALT_MMU_TTB_XN_DISABLE,
	 ALT_MMU_TTB_NS_SECURE},
	{(void *)app_TLB_for_app_MapTo,   //0x00010000
	 (void *)app_TLB_for_app_Address, //0x00010000
	 app_TLB_for_app_Size,    //0x00008000
	 ALT_MMU_AP_FULL_ACCESS,
	 ALT_MMU_ATTR_WBA_WBA,
	 ALT_MMU_TTB_S_NON_SHAREABLE,
	 ALT_MMU_TTB_XN_DISABLE,
	 ALT_MMU_TTB_NS_SECURE},
	{(void *)app_Peripherals_MapTo,   //0xff200000
	 (void *)app_Peripherals_Address, //0xff200000
	 app_Peripherals_Size,    //0x00e00000
	 ALT_MMU_AP_FULL_ACCESS,
	 ALT_MMU_ATTR_DEVICE,
	 ALT_MMU_TTB_S_NON_SHAREABLE,
	 ALT_MMU_TTB_XN_DISABLE,
	 ALT_MMU_TTB_NS_SECURE},
	};

static int InterruptTargets[] = {
/* 000 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 008 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 016 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 024 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 032 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 040 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 048 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 056 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 064 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 072 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 080 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 088 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 096 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 104 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 112 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 120 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 128 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 136 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 144 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 152 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 160 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 168 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 176 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 184 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 192 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 200 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 208 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 216 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 224 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 232 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 240 */  0, 0, 0, 0, 0, 0, 0, 0, 
/* 248 */  0, 0, 0, 0, 0, 0, 0, 0};

#endif

#endif //ifndef LAYOUT_H
