#include "core.h"
#include "trustzone.h"
#include "mempool.h"
#include "gic.h"
#include "cache.h"
#include "mem.h"
#include "alt_interrupt.h"
#include "Layout.h"

uint32 cpu_stack_addrs[2] = { cpu0_Stack_End, cpu1_Stack_End};

void SetupTZMemAccess()
{
  /* Set the default rule to permissive until we have written all the rules */
  alt_sdr_ctl_set_tz_default(ALT_SDR_CTL_PROTPORT_DENY_NONE);
// Secure Memory
  alt_sdr_ctl_set_tz_rule(ALT_SDR_CTL_RULE_NEW, 0, 0x40000000, ALT_SDR_CTL_RULEID_MIN, ALT_SDR_CTL_RULEID_MAX,ALT_SDR_CTL_DATA_ACCESS_SECURE, ALT_SDR_CTL_DATA_RULE_ALL_PORTS, ALT_SDR_CTL_DATA_ALLOW_ACCESS);// Nonsecure Memory
  alt_sdr_ctl_set_tz_rule(ALT_SDR_CTL_RULE_NEW, 0x3ff00000, 0x40000000, ALT_SDR_CTL_RULEID_MIN, ALT_SDR_CTL_RULEID_MAX,ALT_SDR_CTL_DATA_ACCESS_NONSECURE, ALT_SDR_CTL_DATA_RULE_ALL_PORTS, ALT_SDR_CTL_DATA_ALLOW_ACCESS);

  /* Set the default rule to deny access */
  alt_sdr_ctl_set_tz_default(ALT_SDR_CTL_PROTPORT_DENY_CPU); // Deny access to cpus
}

void SetupTZInterrupts()
{
/* All Interrupts are Secure by default */
  int a;
#if defined(NSIntCount)
  for(a=0;a<sizeof(NSInterrupts);a++)
  {
    alt_int_dist_secure_disable(NSInterrupts[a]);
  }
#endif
  for(a=0;a<sizeof(InterruptTargets);a++)
  {
    alt_int_dist_target_set(a, InterruptTargets[a]);
  }
}

void SetupTZPeripherals()
{
  alt_l3_secgrp_set_peripheral_access(0, 0);
}

uint32_t * Map_app(void)
{
    MemPool pool;
    uint32_t *tb;
    MemPoolInit(&pool, 
	app_TLB_for_app_Address, //0x00010000
	app_TLB_for_app_Size);   //0x00008000
    alt_mmu_va_space_create(&tb, app_regions, sizeof(app_regions)/sizeof(app_regions[0]), MemPoolAlloc, &pool);
    alt_mmu_DACR_set(g_domain_ap, 16);
    alt_mmu_TTBCR_set(true, false, 0);
    alt_mmu_TTBR0_set(tb);
    alt_mmu_enable();
    return tb;
}

