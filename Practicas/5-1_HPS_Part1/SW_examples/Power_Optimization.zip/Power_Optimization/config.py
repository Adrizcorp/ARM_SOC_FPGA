serverip  = "10.42.0.1"
ethaddr   = "00:07:ed:33:02:23"
ipaddr    = "10.42.0.2"
